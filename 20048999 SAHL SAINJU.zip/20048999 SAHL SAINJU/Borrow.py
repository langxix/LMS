import dt
import ListSplit

def borrowBook():
    success=False
    while(True):
        firstName=input("Enter the first name of the borrower: ")
        if firstName.isalpha(): # isalpha() method returns the Boolean value True if each character in a string is a letter
            break
        print("please input alphabet from A-Z")
    while(True):
        lastName=input("Enter the last name of the borrower: ")
        if lastName.isalpha():
            break
        print("please input alphabet from A-Z")
            
    t="Borrow-"+firstName+".txt"
    with open(t,"w+") as mf:
        mf.write("               Library Management System  \n")
        mf.write("                   Borrowed By: "+ firstName+" "+lastName+"\n")
        mf.write("    Date: " + dt.getDate()+"    Time:"+ dt.getTime()+"\n\n")
        mf.write("S.N. \t\t   Bookname \t            Authorname \n" )
    
    while success==False:
        print("Please select a option below:")
        for i in range(len(ListSplit.bookname)):
            print("Enter", i, "to borrow book", ListSplit.bookname[i])
    
        try:   
            a=int(input())
            try:
                if(int(ListSplit.quantity[a])>0):
                    print("The book is available for purchase.")
                    with open(t,"a") as mf:
                        mf.write("1. \t\t"+ ListSplit.bookname[a]+"\t\t  "+ListSplit.authorname[a]+"\n")

                    ListSplit.quantity[a]=int(ListSplit.quantity[a])-1
                    with open("Bookstocks.txt","w+") as mf:
                        for i in range(3):
                            mf.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+"\n")
                            print(t)
                            
                    #multiple book borrowing code
                    loop=True
                    count=1
                    while loop==True:
                        choice=str(input("Do you wish to borrow additional books? You cannot, however, borrow the same book twice. Press y for yes and n for no."))
                        if(choice.upper()=="Y"):
                            count=count+1
                            print("Please choose an option from the list below.:")
                            for i in range(len(ListSplit.bookname)):
                                print("Enter", i, "to borrow book", ListSplit.bookname[i])
                            a=int(input())
                            if(int(ListSplit.quantity[a])>0):
                                print("Book is available")
                                with open(t,"a") as mf:
                                    mf.write(str(count) +". \t\t"+ ListSplit.bookname[a]+"\t\t  "+ListSplit.authorname[a]+"\n")

                                ListSplit.quantity[a]=int(ListSplit.quantity[a])-1
                                with open("Bookstocks.txt","w+") as mf:
                                    for i in range(3):
                                        mf.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+"\n")
                                        success=False
                            else:
                                loop=False
                                break
                        elif (choice.upper()=="N"):
                            print ("Thank you for taking out books from our library.. ")
                            print("")
                            loop=False
                            success=True
                        else:
                            print("Please make your selection according to the instructions.")
                        
                else:
                    print("This book is no longer available.")
                    borrowBook()
                    success=False
            except IndexError:
                print("")
                print("Please select a book based on its number..")
        except ValueError:
            print("")
            print("Please select the option that is suggested..")
