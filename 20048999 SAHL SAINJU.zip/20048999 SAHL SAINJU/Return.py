import ListSplit
import dt
def returnBook():
    name=input("Fill in the borrower's name: ")
    a="Borrow-"+name+".txt"
    try:
        with open(a,"r") as mf:
            lines=mf.readlines()
            lines=[a.strip("$") for a in lines]
    
        with open(a,"r") as mf:
            data=mf.read()
            print(data)
    except:
        print("The name of the borrower is wrong")
        returnBook()

    b="Return-"+name+".txt"
    with open(b,"w+")as mf:
        mf.write("                Library Management System \n")
        mf.write("                   Returned By: "+ name+"\n")
        mf.write("    Date: " + dt.getDate()+"    Time:"+ dt.getTime()+"\n\n")
        mf.write("S.N.\t\tBookname\t\tCost\n")


    total=0.0
    for i in range(3):
        if ListSplit.bookname[i] in data:
            with open(b,"a") as mf:
                mf.write(str(i+1)+"\t\t"+ListSplit.bookname[i]+"\t\t$"+ListSplit.cost[i]+"\n")
                ListSplit.quantity[i]=int(ListSplit.quantity[i])+1
            total+=float(ListSplit.cost[i])
            
    print("\t\t\t\t\t\t\t"+"$"+str(total))
    print("Is the deadline for returning the book passed?")
    print("Press Y for Yes and N for No")
    stat=input()
    if(stat.upper()=="Y"):
        print("How many days did the book take to be returned?")
        day=int(input())
        fine=2*day
        with open(b,"a")as mf:
            mf.write("\t\t\t\t\tFine: $"+ str(fine)+"\n")
        total=total+fine
    


    print("Final Total: "+ "$"+str(total))
    with open(b,"a")as mf:
        mf.write("\t\t\t\t\tTotal: $"+ str(total))
    
        
    with open("Bookstocks.txt","w+") as mf:
            for i in range(3):
                mf.write(ListSplit.bookname[i]+","+ListSplit.authorname[i]+","+str(ListSplit.quantity[i])+","+"$"+ListSplit.cost[i]+"\n")
