import Return
import ListSplit
import dt
import Borrow
import Display

def start_screen():
    while(True):
        print("        Welcome to the library management system     ")
        print("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-------")
        print("Enter 1. To Display")
        print("Enter 2. To Borrow a book")
        print("Enter 3. To return a book")
        print("Enter 4. To exit")
        try:
            a=int(input("choose a number from 1-4: "))
            print()
            if(a==1):
                print ("Books Available to Borrow\n")
                print ("Book name, Author name, Quantity, price")
                print("---------------------------------------------------------------------------")
                Display.display()
   
            elif(a==2):
                ListSplit.listSplit()
                Borrow.borrowBook()
            elif(a==3):
                ListSplit.listSplit()
                Return.returnBook()
            elif(a==4):
                print("Thank you for making use of the library management system.")
                break
            else:
                print("Error! Please provide a number between 1-4.")
        except ValueError:
            print("Please enter the information as given..")
start_screen()
