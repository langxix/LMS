def display():
    bookstocks=open('Bookstocks.txt','r')
    for line in bookstocks:
        print (line)
    
